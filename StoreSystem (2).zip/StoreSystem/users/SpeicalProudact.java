/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package users;

/**
 *
 * @author ASUS
 */
public class SpeicalProudact extends Producat {
     private Producat[]speical;
     private String relationship;

    public SpeicalProudact( String relationship,double price) {
        super(relationship,price);
    }
     public SpeicalProudact(Producat[]speical,String name,double price){
        super(name,price);
        this.speical = speical;
          

    }

    


    

    

    public Producat[] getSpeical() {
        return speical;
    }

    public String getRelationship() {
        return relationship;
    }
    public  final void getProudact(String j){
        
        for(Producat b:this.speical)
            if(b.getName().equals(j)){
                System.out.println("( In "+" "+j+")"+"  "+" The relation"+"  "+super.getName()+" "+"between the follwing special Producat:");
              for(int i=0;i<speical.length;i++)
                 System.out.println(speical[i]);
                
                        
            
    }
    }
      
        public String getName() {
        return super.getName();
    }

    public int getID() {
        return super.getID();
    }

    public double getPrice() {
        return super.getID();
    }
    
    
   
     @Override
 public String toString() {
        String s = "\nListing of speical producats \n";
        for (Producat l: speical)
            if (l!= null)
                s += "\n\t-" + l + "\n";
        return s;
    }
   
    }
     
    


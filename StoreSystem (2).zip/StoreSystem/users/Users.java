
package users;

/**
 *
 * @author ASUS
 */
public abstract class Users {

    protected final String name;
     protected final int ID;
protected static  int counter=1000;
    public Users(String name) {
        counter++;
        this.name = name;
        this.ID=counter;
        
        
    }

    public String getName() {
        return name;
    }

    public int getID() {
        return ID;
    }
    
     public String toString(){
         return "[name: "+name+"  "+"ID="+ID+"  ";
     }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package users;

import java.io.File;
import java.util.Scanner;
import java.nio.file.Paths;

public class StoreTest2 {
    
        
        
    public static void main(String[]args)throws Exception{
        
    Scanner s = new Scanner(Paths.get("infor.txt"));
   Scanner input=new Scanner(System.in);
   
   while(s.hasNext()){

        Customers cn=new Customers(s.nextInt(),s.next());
       
        Customers cs=new Customers(s.nextInt(),s.next());
       
        employee e=new employee(s.next(),s.nextDouble());
     
         manger m=new manger(s.next(),s.nextDouble());
       
         System.out.println();
    Users[] use=new Users[4];
    use[0]=cn;
    use[1]=cs;
    use[2]=e;
    use[3]=m;
    
    Store store=new Store(s.next(),use);
    
   
         
       Producat pr1=new Producat(s.next(),s.nextDouble());
     
       Producat pr2=new Producat(s.next(),s.nextDouble());
      
       Producat pr3=new Producat(s.next(),s.nextDouble());
      
       Producat pr4=new Producat(s.next(),s.nextDouble());
       
     Producat pr5=new Producat(s.next(),s.nextDouble());
       
       
     Producat pr7=new  Producat(s.next(),s.nextDouble());
       
     Producat sp1=new Producat(s.next(),s.nextDouble());
     Producat sp2=new Producat(s.next(),s.nextDouble());
     Producat sp3=new Producat(s.next(),s.nextDouble());
    
       
       
       
    store.addProducat(pr1);
    store.addProducat(pr2);
    store.addProducat(pr3);
    store.addProducat(pr4);
    store.addProducat(pr5);
 
    System.out.println(store);
     
    Producat so[]=new Producat[2];
     
    
     so[0]=pr1;
     so[1]=pr2;
     
    Producat s1[]=new Producat[1];
    s1[0]=pr3;
    
    
    Producat s2[]=new Producat[1];
    s2[0]=pr5;
    
   
 Producat[] speical1=new Producat[3];
  speical1[0]=pr7;
  speical1[1]=sp1;
  speical1[2]=sp2;
 
  SpeicalProudact t=new SpeicalProudact(speical1,s.next(),0);
 
  
  Producat[] speical2=new  Producat[2];
  speical2[0]=pr5;
  speical2[1]=sp3;
  
   SpeicalProudact t1=new SpeicalProudact(speical2,s.next(),0);
  
    Customers b2=new Customers(0,"");
   
    System.out.println("1- To Get Store conaines "+"\n"+"2- Update The Salary"+"\n"+"3- "
            + "Add Produacts"+"\n"+"4- Remove Producat"+"\n"+"5- Buy"+"\n"+"6- To Get speical Producat "
            +"\n"+"7- To Get The Users Of The Stores"+"\n"+"8- To Get The Customers Of The Sores"+"\n"+
            "9- To Search For The Producat");
    
       
       
       System.out.println("Choose the opreation you want upon stopping ,set -1");
      boolean q=true; 
      while(q){
     try{
         int enter=input.nextInt();
   while(enter!=-1){
      
           
       
       switch(enter){
           
           case 1:
      
       System.out.println(store);
          
           break;                
       
       case 2:
            System.out.println("Enter The Bouns");
           double x=input.nextDouble();
           System.out.println("Increase All Salarys With"+x+"%");
            m.updateSalary(x);
            System.out.println(m);
            e.updateSalary(x);
            System.out.println(e);
           break;
       case 3:
      System.out.println("Enter Producat Name ");
      String n=input.next();
      System.out.println("Enter Producat Price");
      int j=input.nextInt();
      store.addProducat(new Producat(n,j));
      System.out.println(store);    
        break;
           
       case 4:
           System.out.println("Enter Your ID ");
           int r=input.nextInt();
           store.mreove(r);
           
          break; 
       case 5:
          System.out.println("Enter Customer Name");
           String b=input.next();
           String b1;
           Producat B1;
                   
           System.out.println("How Much You Want To Buy");
           int siz=input.nextInt();
            Producat[] B=new Producat[siz];
            
           for(int i=0;i<B.length;i++){
               System.out.println("Enter Producat Name");
               b1=input.next();
                 System.out.println("Enter Producat Price");
                 siz=input.nextInt();
             B1=new Producat(b1,siz);
             B[i]=B1;
           }
           if(b.equalsIgnoreCase("Najwa")){
                System.out.println("the store before 3 correct buy operation");
            System.out.println(store);
          
                 store.buy(B, cs);
           }
           else if(b.equalsIgnoreCase("Amal")){
             System.out.println("the store before 3 correct buy operation");
                     
            System.out.println(store);
            store.buy(B, cn);
           }
          
           System.out.println("the store After correct buy operation");
           System.out.println(store);
       
           break;
           
       case 6:
          
           System.out.println("Enter The relation Name");
           
           String p=input.next();
            
           if(t.getName().equalsIgnoreCase(p)){
           System.out.println("Enter The Producat Name To Get The Speical Producats Together");
           
           String p1=input.next();
           t.getProudact(p1);
           }
          if(t1.getName().equalsIgnoreCase(p)){
            System.out.println("Enter The Producat Name To Get The Speical 6Producats Together");
           String p1=input.next();
               t1.getProudact(p1);
          }
           break;
       case 7:
        System.out.println("The Users Are:");
      
        for(int i=0;i<use.length;i++)
        System.out.println("-"+use[i].getClass().getSimpleName()+":  "+use[i]+"\n");
        
        System.out.println();
         break;   
       case 8:
        System.out.println("The customers are:");
        System.out.println(cn);
        System.out.println(cs);
           break;
           
       
       
       case 9:
           boolean f;
       System.out.println("Enter The Producat Name");
           String w=input.next();
           System.out.println("Enter The Producat ID");
           int i=input.nextInt();
           f=store.isExist(new Producat(w,i));
           if(f){
               System.out.println("The producat is Exist");
           }
           else
           System.out.println("The producat isn't Exist");
       }
       enter=input.nextInt();
      
   }
    q=false;
       } catch(Exception ex){
           System.out.println(ex);
           System.out.println("Try Agin");
           input.next();
       }
       
 
   
    }
}
    }
}

    
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package users;

/**
 *
 * @author ASUS
 */
public class Customers  extends Users {
private int t;
private String state;

    public void setState(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

   

    public Customers(int t,String s) {
       super(s);
       
        this.t=t;
        this.state="new customer";
    }

    public void setT(int t) {
        
        this.t = t;
    }

    public int getT() {
        return t;
    }
    public final String type(){
        if(this.t<=2)
            return state="new customer";
        if(this.t>2)
            return state="speical customer";
    return null;
    }
    public final void CusKind(){
        t++;
      if(this.t>2){
       state="speical customer";
     setState(state);
      }

    }
    

    public String toString(){
        return super.toString()+"customer type:  "+ " "+type()+"  "+"vistingTime: "+"  "+this.t+"   "+"]";
    }
    
    
}

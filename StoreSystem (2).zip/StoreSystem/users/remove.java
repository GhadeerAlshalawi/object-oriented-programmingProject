/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package users;

import javax.swing.JFrame;
import javax.swing.*;
import java.awt.event.*;

public class remove extends JFrame implements ActionListener {
    Store store;
    private JLabel enter=new JLabel("Enter the producat(S) ID",10); 
    private JLabel e=new JLabel(""); 
    private JTextField en =new  JTextField(10);
    private JButton ok=new JButton("ok");
    private JPanel p1=new JPanel();
    private JPanel p2=new JPanel();
     private JPanel p3=new JPanel();
    public remove(Store s){
        
        store=s;
        
        setLayout(new java.awt.FlowLayout());
        p1.add(enter);
        add(p1);
        
        
        p2.add(en);
        p2.add(ok);
        add(p2);
        ok.addActionListener( this);
        add(p2);
        
        
        
        p3.add(e);
        add(p3);
        
    
        setTitle("remove Producat(s)");
        setSize(320,120);
        setVisible(true);
    
    }

    public JTextField getEn() {
        return en;
    }
    
   
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()==(JButton)ok){
       int id= Integer.parseInt(en.getText());
       
         boolean h=store.mreove1(id);
          
           if(h){
          
           e.setText("we romve it ");
           System.out.println(store);
            }
           else if(!h){
             e.setText("The producat not found");
           System.out.println(store);
           }
    }
    }
    }

    
 

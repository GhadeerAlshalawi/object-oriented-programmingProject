/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package users;

/**
 *
 * @author ASUS
 */
public class manger extends employee {

    public manger(String name, double Salary) {
        super(name, Salary);
    }
    
    
    @Override
     public void updateSalary(double bouns){
          super.updateSalary(bouns);
       }
     public String toString(){
           
           return super.toString()+" ";
    
    }
}

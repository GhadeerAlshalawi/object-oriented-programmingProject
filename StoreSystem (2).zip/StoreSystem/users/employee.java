/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package users;


public class employee extends Users{
    private double Salary;

    public employee(String name ,double Salary) {
        super(name);
        this.Salary = Salary;
    }

    public void setSalary(double Salary) {
        this.Salary = Salary;
    }

    public double getSalary() {
        return Salary;
    }
    
    public int getID(){
        return super.getID();
    }
            
       public void updateSalary(double bouns){
           double newSalary;
            newSalary=(bouns/100)*Salary;
            newSalary=newSalary+Salary;
        setSalary(newSalary);
       }
      
       
       public String toString(){
           
           return "Employee:"+"  "+super.toString()+" "+"the base Salary="+" "+Salary+"]";
       }
    
}

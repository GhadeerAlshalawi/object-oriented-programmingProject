/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package users;

/**
 *
 * @author ASUS
 */
public class Store {
   private Producat[] producat;
   private String nameOfStore;
   private static int producatCount;
   private double price;
   Users [] users;
   int size=100;
    public double getPrice() {
        return price;
    }

  
    public Store(String nameOfStore,Users[] users) {
       
        this.nameOfStore = nameOfStore;
        producat=new Producat[size];
        this.users = users;
    }
    
    public Producat[] getProducat() {
        return producat;
        
    }

    public String getNameOfStore() {
        return nameOfStore;
    }

    public void setProducat(Producat[] producat) {
        this.producat = producat;
    }

    public void setNameOfStore(String nameOfStore) {
        this.nameOfStore = nameOfStore;
    }

    
    public final boolean isExist(Producat p){
        boolean n=false;
        for(int i=0;i<producatCount;i++)
            if(n=this.producat[i].getName().equals(p.getName())){
             
              return true;
            }
          if(n==false){
              
                return false;
     
          }
       return false;
    }
    public final void addProducat(Producat p){
        
        if (this.producatCount<this.producat.length){
            this.producat[producatCount++] =p;
            System.out.println(" we add"+"  "+p.getName()+" "+ "scussfuly");
        }
        else
            System.out.println("the Strore is full we can't add"+p.getName());
    }
    
    public final int search(Producat t){
        for(int i=0;i<producatCount;i++){
            if(producat[i].getName().equals(t.getName()))
                return i;
        }
        return -1;
    }
    
    
    
     public final int Msearch(int t){
        for(int i=0;i<producatCount;i++){
            if(producat[i].getID()==t)
                return i;
        }
        return -1;
    }
    
    public final void remove(Producat b){
        int index=search(b);
        if(index==-1){
            System.out.println("the producat not found");
        
        }else{
            for(int i=index;i<=producatCount-1;i++){
                producat[i]=producat[i+1];
            }
              producat[producatCount-1]=null;
             producatCount--;
            
    }
    }
       public final void mreove(int mID){
          boolean j=false;
       
           for(int i=0;i<users.length;i++)
           if(j=users[i] instanceof manger)
              if(j=users[i].getID()==mID){    
            remove f=new remove(this);
            f.setVisible(true);
              }
           
           if(!j)
           System.out.println("Can't remove Producat."+"\n"+"Only manger can remove the producat");
       }
       
       
      public final boolean mreove1(int mID){
         int index=Msearch(mID);
          if(index==-1){
            System.out.println("the producat not found");
            return false;
        }else{
            for(int i=index;i<producatCount-1;i++){
                producat[i]=producat[i+1];
            }
              producat[producatCount-1]=null;
             producatCount--;
             System.out.println("the producat is remove");
            
             return true;
             
    }
       
    }
    
    public final double totalPrice(Producat[] b,Customers type){
        double dis=0.0;
        double tot=0.0;
      
        for(int i=0;i<b.length;i++)
           {
         tot=tot+b[i].getPrice();
            }
        if(type.getState().equals("new customer")){
            return tot;
        }
     if(type.getState().equals("speical customer")){
        System.out.println("After discount");
        return tot=tot-tot*0.25;
     }
            
     else
       return 0;
   
    }   
   
    public final void buy(Producat b[] ,Customers type){
        boolean n=false;
        double p=0;
        
        type.CusKind();
        System.out.println(type+"\nbought");
        for(int i=0;i<b.length;i++){
            n=isExist(b[i]);
            if(n==false){ 
                    System.out.println("the producat not found!!!!");
                    break;
                }
            
            else{
                 p=totalPrice(b,type);
                System.out.println(b[i]);
            } 
        }
           
               System.out.println("with total price =");
        
               System.out.println(p);
        
              
                 for(int i=0;i<b.length;i++){
                   remove(b[i]);
                 }
                 
    }
    
    

    public String toString(){
       String s = "\n welcome in"+"  "+nameOfStore+" "+"Store it contain"+"  "+producatCount+"  "+ "prosucat(s)\n:";
       
        for (Producat P: this.producat)
            if (P!= null)
                s += "\n\t-" + P + "\n";
         
         s+="thank you for visting";
        
        return s;
    }
    }
    
    

